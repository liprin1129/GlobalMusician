// global var to load essentia instance from wasm build
import { Plotly } from "plotly.js/dist/plotly-basic";
import { EssentiaPlot, PlotMelodyContour } from "essentia.js/dist/essentia.js-plot";

let isEssentiaInstance = false;
// global var for web audio api AudioContext
let audioCtx;
// buffer size microphone stream (bufferSize is high in order to make PitchMelodia algo to work)
let bufferSize = 8192;

try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    audioCtx = new window.AudioContext();
    } 
  catch (e) {
    throw 'Could not instantiate AudioContext: ' + e.message;
  }

// global var getUserMedia mic stream
let gumStream;

// settings for plotting
let plotContainerId = "plotDiv";
let plotMelodyContour = new EssentiaPlot.PlotMelodyContour(Plotly, plotContainerId)
plotMelodyContour.plotLayout.yaxis.range = [80, 4000];
